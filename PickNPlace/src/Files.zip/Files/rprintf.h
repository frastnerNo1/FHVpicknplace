/******************************************************************************
* This file is for rprintf()
*******************************************************************************/
#ifndef rprintf_H
#define rprintf_H

void rprintf_init(void);

void rprintf(const uint8_t *pszFmt,...);

#endif
/* [] END OF FILE */